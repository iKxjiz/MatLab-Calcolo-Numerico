%script scurv2D.m
%Disegno di curve in forma parametrica
clear
close all

open_figure(1);
axis_plot(15,1.0)

%TO DO