%script sbezcurv2d.m
%carica una curva di Bezier e la disegna
clear
close all

open_figure(1);
axis_plot(12,1.0);

%carica file .db con definizione curva di Bezier
%TO DO

%disegna curva di Bezier
%TO DO

%disegna poligonale di controllo
point_plot(cbez.cp,'r-o',2,'k','r',8)

%disegna vettori tangenti
%TO DO
