function [x,y]=c2_curv3(t)
%espressione parametrica della curva def. in [0,16]
%TO DO
return
