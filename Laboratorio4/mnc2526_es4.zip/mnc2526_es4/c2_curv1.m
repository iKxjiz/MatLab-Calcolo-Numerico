function [x,y]=c2_curv1(t)
%espressione parametrica della curva def. in [-0.5,1.5]
%TO DO
return
