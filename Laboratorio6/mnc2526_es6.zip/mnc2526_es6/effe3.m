function y=effe3(x)
%*************************************
% funzione effe3 da integrare in [1,2]
%*************************************
y=exp(-x)./x;
end