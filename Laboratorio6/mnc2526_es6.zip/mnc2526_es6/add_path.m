%aggiunge il path della libreria anmglib ai path di Matlab
addpath ../anmglib_5.0
addpath ../anmglib_5.0/ppbez_code