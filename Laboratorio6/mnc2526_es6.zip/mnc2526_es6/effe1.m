function y=effe1(x)
%**************************************
% funzione effe1 da integrare in [0,12]
%**************************************
y=exp(sqrt(x)).*sin(x)+2.*x-4;