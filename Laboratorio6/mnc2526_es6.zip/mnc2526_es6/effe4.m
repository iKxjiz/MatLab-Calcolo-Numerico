function y=effe4(x)
%*************************************
% funzione effe4 da integrare in [0,1]
%*************************************
y=4./(1+x.^2);
end