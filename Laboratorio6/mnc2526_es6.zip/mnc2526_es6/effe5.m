function y=effe5(x)
%*************************************
% funzione effe5 da integrare in [0,1]
%*************************************
y=sqrt(1-x.^2).*exp(x);
end