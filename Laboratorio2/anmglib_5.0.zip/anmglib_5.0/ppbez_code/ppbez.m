clear all
close all
application = Application;
application.start();