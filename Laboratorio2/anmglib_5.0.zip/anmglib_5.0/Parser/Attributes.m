classdef Attributes
    % Lista di alcuni attributi default
    properties(Constant)
        d = 'd';
        stroke = 'stroke';
        fill = 'fill';
        strokeWidth = 'stroke-width';
        transform = 'transform';
        style = 'style';
        display = 'display';
    end
end

