function [x,y]=c2_cardioide(t)
%espressione parametrica della cardiode con t in [0,2*pi]

%TO DO

return