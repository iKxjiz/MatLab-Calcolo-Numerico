%main di esempio per leggere file di punti e disegnarli
close all
clear

%apre una figure e disegna gli assi
% figure('Position', [10 10 700 600])
open_figure(1);
axis_plot(0.4,0.05)

%legge i punti di un disegno da file

% TO DO

%determina il bounding-box e lo disegna

% TO DO

%disegna la poligonale di vertici i punti

% TO DO


