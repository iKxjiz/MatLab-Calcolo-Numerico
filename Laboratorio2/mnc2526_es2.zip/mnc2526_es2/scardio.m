%script di prova per disegno della cardioide e animazione
%figure('Renderer', 'painters', 'Position', [10 10 1000 800])
clear
close all

% TO DO


