%sgittata di un oggetto lanciato ad un angolo theta
clear all
clc

%TO DO as HomeWork