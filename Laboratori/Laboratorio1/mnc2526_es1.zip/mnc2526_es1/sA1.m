%esercizio A.1
clear all
clc
%definire A

%fare una copia della matrice A e chiamarla B

%copiare la prima riga di A in un vettore a

%sostituire la prima riga di A con l'ultima

%copiare il vettore a nell'ultima riga di A

%definire P come la matrice identità 4x4 con la
%prima e quarta riga scambiate

%definire C come il prodotto di P per B

%stampare le matrici A e C e confrontarle

