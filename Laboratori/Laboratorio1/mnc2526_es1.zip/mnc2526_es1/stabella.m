%Viene generata una tabulazione delle funzioni sin(x), cos(x) e della
%somma dei loro quadrati in corrispondenza di punti equispaziati nell'
%intervallo [0,2*pi]
%input: numero di valori da generare
%output: stampa della tabulazione e stampe ulteriori
clear all
clc


%stampa intestazione e valori
fprintf('  n.    x          sin(x)     cos(x)     sin(x)^2+cos(x)^2\n');
fprintf('%3d> %10.5f %10.5f %10.5f %10.5f\n',[1:n;x;y;z;w]);


%stampa di: indice del valore minimo, valore minimo, 
%indice del valore massimo e valore massimo
%dei valori tabulati per sin(x), cos(x) e la somma dei loro quadrati
fprintf('\n');
