%minimo, massimo e media di una serie di valori
clear all
clc

%TO DO