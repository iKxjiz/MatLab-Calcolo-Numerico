function y=fun3(x)
% esempio di funzione da interpolare
% exp(x)
% definita in [-2,1]
y=exp(x);
end
