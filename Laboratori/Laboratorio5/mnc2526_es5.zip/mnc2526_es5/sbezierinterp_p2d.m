%script sbezierinterp_p2d.m
%interpolazione di un set di punti 2D con curve di Bezier
clear
close all

col=['r','g','b','k'];
open_figure(1);
axis_plot(3,0.25);

%alcuni set di punti da interpolare (commentare/scommentare)
Q=[0,2; 1,1; 2,1; 3,2];
% Q=[0,2; 2,1; 1,1; 3,2];
% Q=[0,0; 1,1; 2,2; 3,3];
% Q=[0,2; 1,1; 2,2; 3,1];
% Q=[5.0000   10.0000
%    1.8       8.7
%    1.8       6.2
%    3.2       3.8
%    3.2       1.3
%    0.0       0.0];

%disegno punti da interpolare
point_plot(Q,'ko:',1.5,'k');

%TO DO
