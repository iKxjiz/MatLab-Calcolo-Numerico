function y=fun1(x)
% esempio di funzione da interpolare
% y=sin(x)-sin(2.*x)
% definita in [-3.14,3.14]
y=sin(x)-sin(2.*x);
