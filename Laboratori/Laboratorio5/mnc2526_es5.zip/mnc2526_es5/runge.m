function y=runge(x)
% funzione test di runge definita in [-5,5]
y=1./(1.+x.^2);
