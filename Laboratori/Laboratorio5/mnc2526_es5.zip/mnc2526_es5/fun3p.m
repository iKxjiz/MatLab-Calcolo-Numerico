function [y,y1]=fun3(x)
% esempio di funzione da interpolare e sua derivata
% definita in [-2,1]
y=exp(x);
y1=y;
end
