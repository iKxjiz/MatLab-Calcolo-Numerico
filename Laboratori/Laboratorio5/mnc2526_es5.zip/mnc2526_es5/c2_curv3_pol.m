function [x,y]=c2_curv3_pol(t)
%espressione parametrica della curva definita in [0,8]
x = t.*cos(t);
y = t.*sin(t);
return
