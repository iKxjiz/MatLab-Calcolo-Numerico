%script spolygon_symm.m
clear
close all

%definisce vettore colori
col=['r','g','b','k','m','y','c'];

%legge i punti di un disegno da file
P=load('paperino2.txt');
%P=load('twitter2.txt');

%TO DO