function [vmin,vmax]=mm_vect(lista)
%determina valore minimo e massimo di una lista di valori
vmin=min(lista);
vmax=max(lista);
return
