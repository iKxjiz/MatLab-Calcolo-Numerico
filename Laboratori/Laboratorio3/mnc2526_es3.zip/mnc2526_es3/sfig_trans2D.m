%script sfig_trans2D.m
%esempio di trasformazione di una figura piana
clear
close all

%apre una figure e disegna gli assi
open_figure(1);
axis_plot(7);

%definisce poligonale FRECCIA-SU e la disegna

%TO DO

%apre una figure e disegna gli assi
open_figure(1);
axis_plot(7);

%definisce matrice di rotazione di angolo alpha rispetto ad un punto 
%TO DO

%applica la matrice di rotazione alla poligonale e la disegna
%TO DO

%determina la matrice SY di trasformazione per simmetria
%TO DO

%applica la matrice di simmetria e disegna
%TO DO
