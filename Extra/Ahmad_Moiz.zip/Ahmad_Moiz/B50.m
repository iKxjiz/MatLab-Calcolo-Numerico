%script
close all
openfig('segnale_fig1.fig');
openfig('segnale_fig2.fig');