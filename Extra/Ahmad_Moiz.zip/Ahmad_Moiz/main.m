%function da realizzare per riprodurre il disegno 
%descritto nell'esercizio B.1
function main()
clear
clc
close all

%TO DO

end