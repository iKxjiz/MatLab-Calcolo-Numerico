function [x,y,z]=c3_line5(t)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [x,y,z]=c3_line5(t)
%Definizione parametrica di una retta 3D
%t     --> parametro in R
%x,y,z --> punto 3D della retta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x = 0;
y = 2;
z = 2*t;
return
