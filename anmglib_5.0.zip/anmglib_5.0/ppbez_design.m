%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Script per la definizione di una curva di Bezier a tratti 
%in modo interattivo grafico
%eseguire lo script dando il nome da command window
%ATTENZIONE: lo script permette di salvare solo curve di Bezier;
%            il file .db verra' salvato nella cartella corrente
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
application = Application;
application.start();
