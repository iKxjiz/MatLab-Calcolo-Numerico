function [x,y,z]=c3_line4(t)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [x,y,z]=c3_line4(t)
%Definizione parametrica di una retta 3D
%t     --> parametro in R
%x,y,z --> punto 3D della retta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x = 0;
y = 2*t;
z = 2*t;
return
